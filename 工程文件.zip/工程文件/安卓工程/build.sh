#!/bin/bash
# 本地播放器 APK 手动构建脚本（不使用 gradle）
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
SDK="$ROOT/sdk"
BT="$SDK/android-14"
PLATFORM="$SDK/android-34-ext12/android.jar"
APP="$ROOT/app"
BUILD="$ROOT/build"
OUT="$ROOT/../本地播放器.apk"
# 使用本地 JDK17（apt 无 root 装不了系统 JDK）
export PATH="$ROOT/jdk-17.0.20.1+1/bin:$PATH"

rm -rf "$BUILD" && mkdir -p "$BUILD/gen" "$BUILD/classes" "$BUILD/dex"

echo "[1/7] aapt2 compile 编译资源..."
"$BT/aapt2" compile --dir "$APP/res" -o "$BUILD/res.zip"

echo "[2/7] aapt2 link 生成 APK 骨架 + R.java..."
"$BT/aapt2" link -o "$BUILD/unsigned.apk" \
    -I "$PLATFORM" \
    --manifest "$APP/AndroidManifest.xml" \
    --java "$BUILD/gen" \
    --min-sdk-version 21 --target-sdk-version 34 \
    "$BUILD/res.zip"

echo "[3/7] javac 编译 Java 源码..."
javac --release 8 \
    -classpath "$PLATFORM" \
    -d "$BUILD/classes" \
    "$BUILD/gen/com/localplayer/app/R.java" \
    "$APP/src/com/localplayer/app/MainActivity.java"

echo "[4/7] d8 转 dex..."
"$BT/d8" --release --lib "$PLATFORM" --output "$BUILD/dex" $(find "$BUILD/classes" -name '*.class')
ls "$BUILD/dex/classes.dex" >/dev/null

echo "[5/7] 打包 classes.dex 与 assets..."
(cd "$BUILD/dex" && zip -q "$BUILD/unsigned.apk" classes.dex)
(cd "$APP" && zip -qr "$BUILD/unsigned.apk" assets)

echo "[6/7] zipalign 对齐..."
"$BT/zipalign" -f 4 "$BUILD/unsigned.apk" "$BUILD/aligned.apk"

echo "[7/7] apksigner 签名..."
if [ ! -f "$ROOT/player.keystore" ]; then
  keytool -genkeypair -keystore "$ROOT/player.keystore" -alias player \
    -keyalg RSA -keysize 2048 -validity 3650 \
    -storepass localplayer -keypass localplayer \
    -dname "CN=LocalPlayer, OU=Dev, O=LocalPlayer, C=CN" >/dev/null 2>&1
fi
"$BT/apksigner" sign --ks "$ROOT/player.keystore" --ks-key-alias player \
    --ks-pass pass:localplayer --key-pass pass:localplayer \
    --out "$OUT" "$BUILD/aligned.apk"

echo "完成: $OUT"
