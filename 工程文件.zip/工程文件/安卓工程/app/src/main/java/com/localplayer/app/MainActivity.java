package com.localplayer.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * 本地 MP3 播放器（Android 版）
 *
 * 两条歌曲来源：
 * 1. 文件选择器（SAF，无需权限）：<input type="file"> 触发 onShowFileChooser
 * 2. 读取手机媒体库：JS 通过 AndroidBridge.loadPhoneMusic() 调原生，
 *    原生申请权限后查询 MediaStore，把歌单 JSON 回传给 window.__onLibrary
 */
public class MainActivity extends Activity {

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQ = 1001;
    private static final int PERM_REQ = 2001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setAllowFileAccess(true);

        webView.setWebViewClient(new WebViewClient());

        // 原生 <-> JS 桥：页面里 window.AndroidBridge.loadPhoneMusic()
        webView.addJavascriptInterface(new JSBridge(), "AndroidBridge");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view,
                                             ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;

                Intent intent = params.createIntent();
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

                try {
                    startActivityForResult(Intent.createChooser(intent, "选择音乐文件"),
                            FILE_CHOOSER_REQ);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQ) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    results = new Uri[n];
                    for (int i = 0; i < n; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    // ---------- 读取手机媒体库的权限结果 ----------
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == PERM_REQ) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadLibrary();
            } else {
                // 用户拒绝权限：通知页面（空列表）
                webView.post(() -> webView.evaluateJavascript(
                        "window.__onLibrary([]);", null));
            }
            return;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    // ---------- JS 桥 ----------
    private class JSBridge {
        @JavascriptInterface
        public void loadPhoneMusic() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33) {
                    // Android 13+：READ_MEDIA_AUDIO
                    if (checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO)
                            != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.READ_MEDIA_AUDIO}, PERM_REQ);
                        return;
                    }
                } else if (Build.VERSION.SDK_INT >= 23) {
                    // Android 6~12：READ_EXTERNAL_STORAGE
                    if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                            != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERM_REQ);
                        return;
                    }
                }
                loadLibrary();
            });
        }
    }

    // ---------- 查询 MediaStore 并把歌单回传给页面 ----------
    private void loadLibrary() {
        new Thread(() -> {
            String[] projection = {
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.DURATION
            };
            Uri audioUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
            StringBuilder sb = new StringBuilder("[");
            try (Cursor c = getContentResolver().query(
                    audioUri, projection, null, null,
                    MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")) {
                if (c != null) {
                    while (c.moveToNext()) {
                        long id = c.getLong(0);
                        String title = c.getString(1);
                        String artist = c.getString(2);
                        long durMs = c.getLong(3);
                        if (title == null) title = "";
                        if (artist == null) artist = "";
                        sb.append("{\"id\":").append(id)
                          .append(",\"title\":\"").append(escapeJson(title))
                          .append("\",\"artist\":\"").append(escapeJson(artist))
                          .append("\",\"duration\":").append(durMs)
                          .append("},");
                    }
                }
            } catch (Exception ignored) {
                // 查询失败按空列表处理
            }
            if (sb.length() > 1) sb.setLength(sb.length() - 1); // 去掉末尾逗号
            sb.append("]");
            final String json = sb.toString();
            runOnUiThread(() -> webView.evaluateJavascript(
                    "window.__onLibrary(" + json + ");", null));
        }).start();
    }

    // JSON 字符串转义，防止特殊字符破坏 JS 结构
    private static String escapeJson(String s) {
        StringBuilder out = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            switch (ch) {
                case '"':  out.append("\\\""); break;
                case '\\': out.append("\\\\"); break;
                case '\n': out.append("\\n");  break;
                case '\r': out.append("\\r");  break;
                case '\t': out.append("\\t");  break;
                default:
                    if (ch < 0x20) {
                        out.append(String.format("\\u%04x", (int) ch));
                    } else {
                        out.append(ch);
                    }
            }
        }
        return out.toString();
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
